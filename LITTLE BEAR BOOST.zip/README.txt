LITTLE BEAR BOOST — HOW TO RUN

Files:
- index.html: the app's HTML, CSS, and JavaScript are all inside this file.
- manifest.json: app name, icon, and home-screen installation settings.
- sw.js: caches the app files so the installed web app can load offline after the first visit.
- bears.png and bear-icon-*.png: art and app icons.

Quick preview:
1. Open index.html in Chrome, Safari, Edge, or Firefox. Quotes and tasks should work.
2. For testing installation/service worker locally, use Visual Studio Code with the Live Server extension and open the folder with Live Server. This serves the app from localhost.
3. To install on a phone or other device, publish the whole folder to an HTTPS host (for example GitHub Pages or Netlify). Open the hosted URL in your browser:
   - iPhone/iPad: Safari → Share → Add to Home Screen.
   - Android: Chrome menu → Install app / Add to Home screen.
   - Supported desktop browsers: use the install icon or browser menu.
A local HTML file alone cannot be installed as a full PWA. This creates an app icon/standalone app, not a native live home-screen widget.

Languages:
- HTML = structure/content
- CSS = design/layout/colors
- JavaScript = quote buttons, to-do list, saving tasks, and install behavior
- JSON = manifest configuration (not a programming language)

Online quote sources included in the app:
- BrainyQuote, Motivational Quotes: https://www.brainyquote.com/topics/motivational-quotes
Original quotes are labeled "Little Bear original" inside the app.
